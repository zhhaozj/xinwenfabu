package com.shujvku.cn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Shujvku {
	static Connection con = null;
	static Statement stmt = null;
	ResultSet rs = null;
	static String driverClass = "com.mysql.jdbc.Driver";
	static String url = "jdbc:mysql://localhost:3306/news";
 	static String username = "root";
	static String password = "123456";

	public Shujvku(){
		try {
			Class.forName(driverClass);
			con = DriverManager.getConnection(url,username,password);
			stmt = con.createStatement();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e){
			e.printStackTrace();
		}
		
	}
	
	public static Connection getConn(){
		return con;
	}

	public ResultSet query(String sql){
		try {
			rs = stmt.executeQuery(sql);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rs;
	}
	public void addData(String sql){
		try {
			Statement stmt = con.createStatement();
			stmt.executeUpdate(sql);
			System.out.println("�������ӳɹ�");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void delData(String sql){
		try {
			Statement stmt = con.createStatement();
			stmt.executeUpdate(sql);
			System.out.println("����ɾ���ɹ�");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void midifyData(String sql){
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(sql);
			System.out.println("�޸ĳɹ�");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
}

